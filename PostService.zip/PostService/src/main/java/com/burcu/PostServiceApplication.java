package com.burcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostServiceApplication {
    public static void main(String[] args) {

        SpringApplication.run(PostServiceApplication.class, args);
    }

    /**
     * post-service mod�l�n� olu�tural�m.
     * gerekli katmanlar� ekleyelim.
     * Ondan sonra bir "Post" olu�tural�m. Bitirenler bu mesaja emoji atabilir.
     */
}